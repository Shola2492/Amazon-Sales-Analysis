# Amazon-Sales-Analysis
Amazon Sales Dashboard (2025) - Power BI &amp; Excel Analysis  🔍 Analyzed 10K+ sales records to uncover:  Quarterly revenue trends  Top-performing product categories  Regional sales performance  🛠️ Tools Used:  Power BI (interactive dashboards, DAX)  Excel (data cleaning, Power Query, pivot tables)
